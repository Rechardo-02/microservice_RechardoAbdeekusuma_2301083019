package com.rechardo.produk.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rechardo.produk.model.pelanggan;
import com.rechardo.produk.service.pelangganService;

@RestController
@RequestMapping("/api/pelanggan")
public class pelangganController {
    @Autowired
    private pelangganService pelangganService;

    @GetMapping
    public List<pelanggan> getAllPelangganService(){
        return pelangganService.getAllPelanggan();
    }

    @GetMapping("/{id}")
    public ResponseEntity<pelanggan> getPelangganById(@PathVariable Long id) {
        pelanggan pelanggan = pelangganService.getPelangganById(id);
        return pelanggan != null ? ResponseEntity.ok(pelanggan) : ResponseEntity.notFound().build();
    }

   @PostMapping
    public ResponseEntity<pelanggan> createPelanggan (@RequestBody pelanggan pelanggan) {
        pelanggan createdPelanggan = pelangganService.createPelanggan(pelanggan);
        return ResponseEntity.ok(createdPelanggan);
    }

    @PostMapping("/{id}")
    public ResponseEntity<pelanggan> updatePelanggan(@PathVariable Long id, @RequestBody pelanggan pelanggan) {
        pelanggan existing = pelangganService.getPelangganById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        // copy updatable fields
        existing.setNama(pelanggan.getNama());
        existing.setAlamat(pelanggan.getAlamat());
        pelanggan updated = pelangganService.savePelanggan(existing);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePelanggan(@PathVariable Long id) {
        pelangganService.deletePelanggan(id);
        return ResponseEntity.ok().build();
    }

}

