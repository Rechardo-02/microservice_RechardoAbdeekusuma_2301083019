package com.rechardo.produk.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rechardo.produk.model.order;
import com.rechardo.produk.service.orderService;

@RestController
@RequestMapping("/api/order")
public class orderController {
    @Autowired
    private orderService orderService;

    @GetMapping
    public List<order> getAllOrderService(){
        return orderService.getAllOrder();
    }

    @GetMapping("/{id}")
    public ResponseEntity<order> getOrderById(@PathVariable Long id) {
        order order = orderService.getOrderById(id);
        return order != null ? ResponseEntity.ok(order) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<order> createOrder(@RequestBody order order) {
        if (order != null) {
            order.setTotal(order.getHarga() * order.getJumlah());
        }
        order createdOrder = orderService.createOrder(order);
        return ResponseEntity.ok(createdOrder);
    }

   @PostMapping("/{id}")
    public ResponseEntity<order> updateOrder(@PathVariable Long id,
                                                 @RequestBody order order) {
        order existing = orderService.getOrderById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        // copy updatable fields
        existing.setId_produk(order.getId_produk());
        existing.setId_pelanggan(order.getId_pelanggan());
        existing.setHarga(order.getHarga());
        existing.setJumlah(order.getJumlah());
        existing.setTotal(order.getHarga() * order.getJumlah());
        order updated = orderService.saveOrder(existing);
        return ResponseEntity.ok(updated);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
        return ResponseEntity.ok().build();
    }

}

