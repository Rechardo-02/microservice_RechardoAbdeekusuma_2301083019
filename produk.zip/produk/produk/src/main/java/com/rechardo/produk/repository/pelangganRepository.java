package com.rechardo.produk.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rechardo.produk.model.pelanggan;

@Repository
public interface pelangganRepository extends JpaRepository<pelanggan, Long> {

}

