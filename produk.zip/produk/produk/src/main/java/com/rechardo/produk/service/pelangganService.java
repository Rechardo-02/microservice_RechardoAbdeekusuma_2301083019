package com.rechardo.produk.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rechardo.produk.model.pelanggan;
import com.rechardo.produk.repository.pelangganRepository;

@Service
public class pelangganService {
    @Autowired
    private pelangganRepository pelangganRepository;

    public List<pelanggan> getAllPelanggan() {
        return pelangganRepository.findAll();
    }
    public pelanggan getPelangganById(Long id) {
        return pelangganRepository.findById(id).orElse(null);
    }
    public pelanggan savePelanggan(pelanggan pelanggan) {
        return pelangganRepository.save(pelanggan);
    }
    public void deletePelanggan(Long id) {
        pelangganRepository.deleteById(id);
    }
    public pelanggan createPelanggan(pelanggan pelanggan) {
        return pelangganRepository.save(pelanggan);
    }
}