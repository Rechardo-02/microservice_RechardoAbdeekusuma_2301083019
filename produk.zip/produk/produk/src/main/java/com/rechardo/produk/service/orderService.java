package com.rechardo.produk.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rechardo.produk.model.order;
import com.rechardo.produk.repository.orderRepository;

@Service
public class orderService {
    @Autowired
    private orderRepository orderRepository;

    public List<order> getAllOrder() {
        return orderRepository.findAll();
    }
    public order getOrderById(Long id) {
        return orderRepository.findById(id).orElse(null);
    }
    public order saveOrder(order order) {
        // calculate total before saving if not provided or recalculation
        if (order != null) {
            double harga = order.getHarga();
            int jumlah = order.getJumlah();
            order.setTotal(harga * jumlah);
        }
        return orderRepository.save(order);
    }
    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }
    public order createOrder(order order) {
        if (order != null) {
            double harga = order.getHarga();
            int jumlah = order.getJumlah();
            order.setTotal(harga * jumlah);
        }
        return orderRepository.save(order);
    }
}